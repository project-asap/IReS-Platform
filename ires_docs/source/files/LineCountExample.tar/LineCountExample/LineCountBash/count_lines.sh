#!/bin/bash
wc -l $1 >> $2
