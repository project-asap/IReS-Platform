#!/bin/bash
echo "Hello world" >> $1