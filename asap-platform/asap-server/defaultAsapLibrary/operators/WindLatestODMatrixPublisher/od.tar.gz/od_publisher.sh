python od_publisher.py $1
